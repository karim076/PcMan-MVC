﻿namespace PcMan.Model.Charachters
{
    internal interface ICollectable
    {
        public void PickUp();

        public int GetValue();
    }
}