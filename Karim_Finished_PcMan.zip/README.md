## PcMan 
This project was a school mission, the game is made in the terminal.<br>

# Whats needed to run this game
Language used: ![C#](https://img.shields.io/badge/c%23-%23239120.svg?style=for-the-badge&logo=c-sharp&logoColor=white)<br>
FrameWork: ![.Net](https://img.shields.io/badge/.NET-5C2D91?style=for-the-badge&logo=.net&logoColor=white)<br>
IDEs/Editors: ![Visual Studio](https://img.shields.io/badge/Visual%20Studio-5C2D91.svg?style=for-the-badge&logo=visual-studio&logoColor=white)
# Whats in it?
* a Player that can play around🚹<br>
* a Enemy Teleporter 👻, its an enmey that teleports after a few seconds<br>
* a Enemy bouncer⚽, this enemy bounces around the game<br>
* Collectables , You can pickup coins 🪙<br>
* Levels (1 to 5)🏆<br>
* Lifes, if you get touched by the enemy x amount of times you die💀<br>
* End results, both for losing❌ and winning🏆
# What is custumizable
* Level up Requirment
* Lifes❤️
* Speed of the enemy's
* width↔️ and the height↕️ of the game
# Language
And in the language netherlands(Questions only or end Messages) but the comments are english <br>to understand what a method or a function do
# Credits
Made by <a href="www.github.com/karim076">Karim Alkichouhi<a> From Scratch
